import numpy as np
from collections import defaultdict

# Normal de uma face (método de Newell)
# Funciona para polígonos com qualquer número de vértices.

def normal_newell(face, vertices):

    n = np.zeros(3, dtype=float)

    m = len(face)

    for i in range(m):

        p = np.asarray(vertices[face[i]], dtype=float)
        q = np.asarray(vertices[face[(i + 1) % m]], dtype=float)

        n[0] += (p[1] - q[1]) * (p[2] + q[2])
        n[1] += (p[2] - q[2]) * (p[0] + q[0])
        n[2] += (p[0] - q[0]) * (p[1] + q[1])

    norma = np.linalg.norm(n)

    if norma < 1e-12:
        return None

    return n / norma


# Constrói o mapa:
# aresta -> faces que usam essa aresta

def construir_adjacencias(faces):

    arestas = defaultdict(list)

    for indice_face, face in enumerate(faces):

        m = len(face)

        for i in range(m):

            a = face[i]
            b = face[(i + 1) % m]

            aresta = tuple(sorted((a, b)))

            arestas[aresta].append(indice_face)

    return arestas


# Calcula o diedral orientado entre duas faces

def diedral_orientado(face1, face2, aresta, vertices):

    n1 = normal_newell(face1, vertices)
    n2 = normal_newell(face2, vertices)

    if n1 is None or n2 is None:
        return None

    a, b = aresta

    eixo = np.asarray(vertices[b], dtype=float) - np.asarray(vertices[a], dtype=float)

    norma = np.linalg.norm(eixo)

    if norma < 1e-12:
        return None

    eixo /= norma

    seno = np.dot(eixo, np.cross(n1, n2))
    cosseno = np.dot(n1, n2)

    theta = np.degrees(np.arctan2(seno, cosseno))

    if theta < 0:
        theta += 360.0

    # sempre o menor diedral
    if theta > 180.0:
        theta = 360.0 - theta

    return theta

# Calcula todos os diedrais do sólido

def calcular_angulos_diedrais(vertices, faces):

    adj = construir_adjacencias(faces)

    angulos = []

    for aresta, lista_faces in adj.items():

        if len(lista_faces) != 2:
            continue

        f1 = faces[lista_faces[0]]
        f2 = faces[lista_faces[1]]

        theta = diedral_orientado(f1, f2, aresta, vertices)

        if theta is not None:
            angulos.append(theta)

    angulos = np.asarray(angulos)

    angulos.sort()

    return angulos

# Compara dois conjuntos de diedrais
def diedrais_iguais(a1, a2, tol=1e-6):

    a1 = np.asarray(a1)
    a2 = np.asarray(a2)

    if len(a1) != len(a2):
        return False

    return np.allclose(a1, a2, atol=tol, rtol=0)