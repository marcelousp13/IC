from collections import defaultdict, deque

def corrigir_orientacao_faces(faces):
    """
    Corrige a orientação das faces de uma malha topológica,
    garantindo consistência global entre faces adjacentes.
    Mantém a estrutura BFS e lógica de arestas do código original.
    """
    edge_to_faces = defaultdict(list)
    for fi, face in enumerate(faces):
        m = len(face)
        for i in range(m):
            key = tuple(sorted((face[i], face[(i+1) % m])))
            edge_to_faces[key].append(fi)

    oriented = [None] * len(faces)
    processed = [False] * len(faces)
    oriented[0] = list(faces[0])
    processed[0] = True
    queue = deque([0])

    while queue:
        fi = queue.popleft()
        ref = oriented[fi]

        for i in range(len(ref)):
            a, b = ref[i], ref[(i+1) % len(ref)]
            key = tuple(sorted((a, b)))

            for nbr in edge_to_faces[key]:
                if nbr == fi or processed[nbr]:
                    continue
                f2 = list(faces[nbr])
                m = len(f2)
                # verifica se a aresta comum está invertida
                for k in range(m):
                    x, y = f2[k], f2[(k+1) % m]
                    if {x, y} == {a, b}:
                        if (x, y) == (a, b):
                            # a aresta está no mesmo sentido -> inverte
                            f2.reverse()
                        break
                oriented[nbr] = f2
                processed[nbr] = True
                queue.append(nbr)

    # faces isoladas que não foram alcançadas
    for i, f in enumerate(oriented):
        if f is None:
            oriented[i] = list(faces[i])

    # checagem de consistência global: mantém a maioria das orientações
    consistent = []
    seen_edges = {}
    for f in oriented:
        for i in range(len(f)):
            a, b = f[i], f[(i+1)%len(f)]
            key = (a,b)
            if (b,a) in seen_edges:
                consistent.append(True)
            else:
                seen_edges[key] = True

    ratio = sum(consistent) / len(consistent) if consistent else 1
    if ratio < 0.5:
        # Se a maioria das faces ainda estiver invertida, inverte tudo
        oriented = [list(reversed(f)) for f in oriented]

    return oriented
