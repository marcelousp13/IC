import numpy as np

def verificar_minimo_degenerado(vertices, faces, verbose=False):
    """
    Confere se uma solução é degenerada (colapsada ou inválida geometricamente).
    Retorna True se for degenerada, False se for um mínimo válido.

    Parâmetros:
        vertices: np.ndarray shape (n, 3)
        faces: lista de listas com índices de vértices
        verbose: imprime detalhes se True
    """

    V = np.array(vertices, dtype=float)
    n = len(V)

    # ---------- 1. Checagem básica: vértices duplicados ----------
    dist = np.linalg.norm(V[:, None, :] - V[None, :, :], axis=-1)
    np.fill_diagonal(dist, np.inf)
    min_dist = np.min(dist)
    if min_dist < 1e-4:  # distância muito pequena
        if verbose:
            print(f"⚠️ Degenerado: vértices colapsados (distância mínima = {min_dist:.3e})")
        return True

    # ---------- 2. Checagem de áreas das faces ----------
    def face_area(f):
        if len(f) < 3:
            return 0
        pts = V[f]
        normal = np.cross(pts[1] - pts[0], pts[2] - pts[0])
        return 0.5 * np.linalg.norm(normal)
    
    areas = np.array([face_area(f) for f in faces])
    small_areas = np.sum(areas < 1e-5)
    if small_areas > 0:
        if verbose:
            print(f"⚠️ Degenerado: {small_areas} faces com área ≈ 0")
        return True

    # ---------- 3. Volume total aproximado ----------
    def face_volume(f):
        if len(f) < 3:
            return 0
        a, b, c = V[f[:3]]
        return np.dot(a, np.cross(b, c)) / 6.0

    volumes = np.array([face_volume(f) for f in faces])
    total_volume = np.sum(volumes)
    if abs(total_volume) < 1e-4:
        if verbose:
            print(f"⚠️ Degenerado: volume total ~ 0 (|V|={abs(total_volume):.3e})")
        return True

    # ---------- 4. Sanity check: dispersão espacial ----------
    bbox = V.max(axis=0) - V.min(axis=0)
    if np.any(bbox < 1e-3):
        if verbose:
            print(f"⚠️ Degenerado: bounding box achatado ({bbox})")
        return True

    # Se passou por todos os testes:
    if verbose:
        print("✅ Sólido válido (não degenerado)")
    return False
