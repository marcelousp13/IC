import os
import numpy as np


def calcular_distancias(vertices):
    """
    Calcula todas as distâncias entre pares de vértices.
    Retorna um vetor ordenado.
    """
    distancias = []

    n = len(vertices)

    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(
                np.asarray(vertices[i]) - np.asarray(vertices[j])
            )
            distancias.append(d)

    distancias = np.sort(np.asarray(distancias))

    return distancias


def salvar_solido(
    nome_solido,
    vertices,
    distancias,
    angulos,
    fval,
    pasta_base=None,
    tol=1e-6
):

    if pasta_base is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        pasta_base = os.path.join(os.path.dirname(script_dir), "solidos")

    pasta_solido = os.path.join(pasta_base, nome_solido)
    os.makedirs(pasta_solido, exist_ok=True)

    banco = os.path.join(pasta_solido, "minimos.npy")
    pts_path = os.path.join(pasta_solido, "pontos.txt")

    # -------------------------------------------------
    # Carrega banco
    # -------------------------------------------------

    if os.path.exists(banco):
        dados = np.load(banco, allow_pickle=True).tolist()
    else:
        dados = []

    # -------------------------------------------------
    # Procura duplicatas
    # -------------------------------------------------

    for antigo in dados:

        if (
            np.allclose(
                antigo["distancias"],
                distancias,
                atol=tol,
                rtol=0
            )
            and
            np.allclose(
                antigo["angulos"],
                angulos,
                atol=tol,
                rtol=0
            )
            and
            abs(antigo["fval"] - fval) <= tol
        ):
            return False

    # -------------------------------------------------
    # Novo sólido
    # -------------------------------------------------

    dados.append({
        "distancias": np.asarray(distancias),
        "angulos": np.asarray(angulos),
        "fval": float(fval)
    })

    np.save(banco, dados)

    with open(pts_path, "a") as f:

        f.write("Novo mínimo encontrado:\n")

        for i, v in enumerate(vertices):
            f.write(
                f"v[{i}] = [{v[0]:.6f}, {v[1]:.6f}, {v[2]:.6f}]\n"
            )

        f.write("\n")

    return True