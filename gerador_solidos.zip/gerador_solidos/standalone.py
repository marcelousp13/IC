import os
import time
import numpy as np
import json
from itertools import combinations
from datetime import datetime
from core.loader import carregar_solidos
from core.orientacao import corrigir_orientacao_faces
from core.geometria import gradiente, gerar_segmentos
from core.distancias import calcular_distancias, salvar_solido
from core.conferindo import verificar_minimo_degenerado
from core.diedrais import calcular_angulos_diedrais

# Função energia 
def energia(vc, segmentos):
    diffs = []
    for (i, j, d2) in segmentos:
        vi, vj = vc[int(i)], vc[int(j)]
        diffs.append((np.linalg.norm(vi - vj) ** 2 - d2) ** 2)  #gerador de funções
    return 0.5 * sum(diffs)   #tira o valor de arestas


# Hessiana por diferenças finitas 
def hessiana(vc, segmentos, eps=1e-6):
    n = vc.size
    H = np.zeros((n, n))
    g0 = gradiente(vc, segmentos).reshape(-1)
    for k in range(n):
        vc_pert = vc.copy().reshape(-1)
        vc_pert[k] += eps
        vc_pert = vc_pert.reshape(vc.shape)
        g1 = gradiente(vc_pert, segmentos).reshape(-1)
        H[:, k] = (g1 - g0) / eps
    return H    #pronto do git, talvez seja bom estudar sobre

# verifica se 3 pontos são colineares 
def pontos_colineares(p1, p2, p3, epsilon=1e-5):
    return np.linalg.norm(np.cross(p2 - p1, p3 - p1)) <= epsilon


def possui_face_colinear(vc, faces, epsilon=1e-5):
    for face in faces:
        # testa todas as combinações de 3 vértices da face
        for i, j, k in combinations(face, 3):
            if pontos_colineares(vc[i], vc[j], vc[k], epsilon):
                print(f"Colinearidade encontrada na face {face}: vértices ({i}, {j}, {k})")
                return True
    return False

#  Salvar solução em JSON e TXT 
def salvar_solucao(nome_solucao, tipo, nome_solido, vc, distancias, angulos, autovalores, fval):
    base = "globais" if tipo == "global" else "locais"

    # Caminho relativo à pasta do script, dentro de "solidos"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    solido_dir = os.path.join(script_dir, "solidos", nome_solido, base)
    os.makedirs(solido_dir, exist_ok=True)

    # Nome base do arquivo
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{nome_solucao}_{timestamp}"
    json_path = os.path.join(solido_dir, filename + ".json")
    txt_path = os.path.join(solido_dir, filename + ".txt")

    # Estrutura a ser salva em JSON
    dados = {
        "nome": nome_solido,
        "tipo": tipo,
        "fval": fval,
        "vc": vc.tolist(),
        "distancias": distancias.tolist(),
        "angulos_diedrais": angulos.tolist(),
        "autovalores": autovalores.tolist(),
        "timestamp": datetime.now().isoformat()
    }

    # Salvar em JSON
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)

    # Salvar também em TXT
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(f"Solução: {nome_solucao}\n")
        f.write(f"Tipo: {tipo}\n")
        f.write(f"Valor da função (fval): {fval:.6e}\n")
        f.write(f"Autovalores: {autovalores.tolist() if hasattr(autovalores, 'tolist') else autovalores}\n")
        f.write("\n--- Distâncias ---\n")
        for d in (distancias.tolist() if hasattr(distancias, "tolist") else distancias):
            f.write(str(d) + "\n")
        f.write("\n--- Ângulos diedrais ---\n")
        for a in angulos:
            f.write(f"{a}\n")
        f.write("\n--- Pontos (vc) ---\n")
        for v in (vc.tolist() if hasattr(vc, "tolist") else vc):
            f.write(str(v) + "\n")

    print(f"Solução salva em:\n - {json_path}\n - {txt_path}")


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    faces_path = os.path.join(script_dir, 'faces.txt')

    solidos = carregar_solidos(faces_path)
    nome = input("Digite o nome do sólido: ").strip()
    if nome not in solidos:
        print(f"Sólido '{nome}' não encontrado em faces.txt.")
        return

    faces, _ = solidos[nome]
    faces = corrigir_orientacao_faces(faces)
    segmentos = gerar_segmentos(faces)

    # quantas repetições (m)
    m_input = input("Quantas vezes deseja gerar o sólido? (Enter = infinito) ").strip()
    try:
        m = None if m_input == "" else int(m_input)
    except Exception:
        print("Entrada inválida para 'm'. Usando m = 1.")
        m = 1

    # Parâmetros
    alpha = 0.001
    grad_tol = 1e-14
    max_iter = 1000000
    max_step = 0.1
    save_nonconverged = False

    rep = 0
    encontrados = 0
    contador_globais = 0

    try:
        while True:
            rep += 1
            if m is not None and rep > m:
                print("Finalizado número de repetições solicitado.")
                break

            suffix = f"/{m}" if m is not None else ""
            print(f"\n=== Execução {rep}{suffix} para '{nome}' ===")

            nv = int(segmentos[:, :2].max()) + 1
            vc = np.random.uniform(-1, 1, (nv, 3))
            vel = np.zeros_like(vc)

            converged = False
            start_time = time.time()
            for it in range(1, max_iter + 1):
                g = gradiente(vc, segmentos, max_step=max_step)
                norm_g = np.linalg.norm(g)

                if it % 10000 == 0:
                    print(f"Iter {it:6d} | ||grad|| = {norm_g:.6e}")

                if norm_g <= grad_tol:
                    converged = True
                    print(f"Convergiu em {it} iterações (||grad|| = {norm_g:.6e}).")
                    break

                vel = vel * 0.99 - alpha * g
                vc += vel

            elapsed = time.time() - start_time
            fval = energia(vc, segmentos)
            distancias = calcular_distancias([tuple(v) for v in vc])
            angulos = calcular_angulos_diedrais(vc, faces)
            H = hessiana(vc, segmentos)
            autovalores = np.linalg.eigvalsh(H)

            # Apenas mínimos globais serão considerados
            if abs(fval) < 1e-6:
                tipo = "global"
                contador_globais += 1
                nome_solucao = f"solucao_global_{contador_globais}"
                print(f"{nome_solucao} encontrado: f={fval:.6e}")
            else:
                print(f"Mínimo local encontrado (f={fval:.6e}) — descartado.")
                continue

            if not converged:
                print(f"Não convergiu em {max_iter} iterações (||grad|| = {norm_g:.6e}). Tempo: {elapsed:.2f}s")

            # Verificação de mínimo degenerado 
            vertices = [tuple(v) for v in vc]

            if verificar_minimo_degenerado(vc, faces):
                print("Mínimo degenerado detectado — não será salvo.")
                continue
            if possui_face_colinear(vc, faces):
                print("Face não convexa (3 vértices colineares).")
                continue

            # Usa salvar_solido para decidir duplicatas
            if converged or save_nonconverged:
                saved = salvar_solido(nome, vertices, distancias, angulos, fval, tol=1e-6)
                if saved:
                    encontrados += 1
                    salvar_solucao(nome_solucao, tipo, nome, vc, distancias, angulos, autovalores, fval)
                    print("Sólido salvo (novo).")
                else:
                    print("Sólido não salvo (provável duplicata dentro da tolerância).")
            else:
                print("Execução descartada (não convergiu e save_nonconverged=False).")
    
    except KeyboardInterrupt:
        print("\nInterrompido pelo usuário (Ctrl+C).")
    #Resumo  final
    print("\nResumo final:")
    print(f" - Mínimos globais encontrados: {contador_globais}")
    print(f" - Total de mínimos distintos salvos: {encontrados}")


if __name__ == '__main__':
    main()